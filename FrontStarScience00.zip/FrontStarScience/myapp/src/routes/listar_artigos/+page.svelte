<script>

    import Footer from "$lib/Footer.svelte";
    import Menu from "$lib/Menu.svelte";

</script>
<!DOCTYPE html>
<!-- svelte-ignore a11y-missing-attribute -->
<html>
<head>
<title>Listar Artigos</title>
</head>
<body>
    <h1>Listar Artigos</h1>
</body>
</html>

<style>
      body{
    font-family: Verdana, Geneva, Tahoma, sans-serif;
    background-color: rgb(255, 255, 255);
    margin: 10px 10px 10px 10px;
    padding: 0;
  }

  /* Estilo para o título h1 */
h1 {
  font-size: 36px;
  font-weight: normal;
  color: #000000;
  text-align: center;
  margin: 20px 0px 0px 0px;
}
</style>
