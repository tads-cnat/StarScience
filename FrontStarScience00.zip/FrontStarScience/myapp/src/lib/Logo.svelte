<img src="logoSS.png" class="logo-SS" alt="Logo Star Science"/>

<style>
    .logo-SS{
        height: 5rem;
    }
</style>