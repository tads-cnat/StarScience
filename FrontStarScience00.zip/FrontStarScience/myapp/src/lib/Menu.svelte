<script>

    import Logo from "./Logo.svelte";

</script>
<div>
    <!-- svelte-ignore a11y-missing-attribute -->
    <a href="/">
        <!-- svelte-ignore a11y-missing-attribute -->
        <!-- svelte-ignore missing-declaration -->
        <Logo />
    </a>
</div>
<a href="/cadastrar_artigos" class="border-b-2 border-transparent hover:text-gray-800 transition-colors duration-300 transform dark:hover:text-gray-200 hover:border-blue-500 mx-1.5 sm:mx-6">Cadastrar Artigos</a>
<a href="/cadastrar_categorias" class="border-b-2 border-transparent hover:text-gray-800 transition-colors duration-300 transform dark:hover:text-gray-200 hover:border-blue-500 mx-1.5 sm:mx-6">Cadastrar Categorias</a>
<a href="/listar_artigos" class="border-b-2 border-transparent hover:text-gray-800 transition-colors duration-300 transform dark:hover:text-gray-200 hover:border-blue-500 mx-1.5 sm:mx-6">Listar Artigos</a>

